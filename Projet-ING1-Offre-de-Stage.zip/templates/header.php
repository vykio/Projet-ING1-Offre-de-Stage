<title><?php echo PAGE_NAME ?></title>

<!-- Skeleton CSS -->
<link rel="stylesheet" type="text/css" href="src/css/skeleton/normalize.css">
<link rel="stylesheet" type="text/css" href="src/css/skeleton/skeleton.css">
<link rel="stylesheet" type="text/css" href="src/css/global/global.css">
<link rel="stylesheet" type="text/css" href="src/css/global/menu.css">

<div id="notification-con"></div>
<link rel="stylesheet" type="text/css" href="src/modules/notifications/notifications.css">
<script type="text/javascript" src="src/modules/notifications/notifications.js"></script>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.0/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1">