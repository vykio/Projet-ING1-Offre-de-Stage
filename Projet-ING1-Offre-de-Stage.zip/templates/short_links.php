<?php 

$page_index = "index.php";
$page_login = "login.php";
$page_register = "register.php";
$page_logout = "logout.php";
$page_annonce = "annonce.php";
$page_profil = "profile.php";
$page_myspace = "myspace.php";
$page_creerannonce = "creerannonce.php";
$page_deleteannonce = "deleteannonce.php";
$page_modifannonce  = "modifannonce.php";
$page_administration = "administration.php";

define('INDEX_PAGE', $page_index);
define('LOGIN_PAGE', $page_login);
define('REGISTER_PAGE', $page_register);
define('LOGOUT_PAGE', $page_logout);
define('ANNONCE_PAGE', $page_annonce);
define('PROFILE_PAGE', $page_profil);
define('MYSPACE_PAGE',$page_myspace);
define('CREERANNONCE_PAGE', $page_creerannonce);
define('DELETEANNONCE_PAGE', $page_deleteannonce);
define('MODIFANNONCE_PAGE', $page_modifannonce);
define('ADMINISTRATION_PAGE', $page_administration);
?>