<div class="footer"> <?php // Il faut global.css  ?>
	Projet informatique - 1ère année Ecole d'Ingénieurs du Littoral Côte d'Opale - Groupe TP12&emsp;<a href="https://github.com/vykio/Projet-ING1-Offre-de-Stage" target="_blank" style="text-decoration: none; color: black"><i class="fab fa-github"></i></a>
</div>